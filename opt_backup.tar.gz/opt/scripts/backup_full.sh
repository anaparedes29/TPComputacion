!/bin/bash
function mostrar_ayuda(){
echo "uso: $0 <directorio_origen><directorio-destino>"
echo "script para realizar backups de directorios"
echo "Parametros"
echo "directorio_origen: directorio a respaldar"
echo "directorio_destino: directorio donde se guardara el backup"
echo "opciones"
echo "-help muestra esta ayuda"
echo "ejemplos:"
echo "$0 /var/log /backup_dir"
echo "$0 /www_dir /backup_dir"
exit 0
}

if [[ "$1" == "-help" ]]; then
    mostrar_ayuda
fi 

if [[ $# -ne 2]]; then
echo "error: se requiere dos parametros (origen y destino)"
echo  "use $0 -help para mas informacion"
exit 1
fi

ORIGEN=$1
DESTINO=$2

if [[! -d "$ORIGEN"]]; then
echo "el directorio $origen no esta montado"
exit 1
fi

if [[! -d "$DESTINO"]]; then
echo "el directorio destino no existe o no esta montado"
exit 1
fi

if ! mountpoint -q "$DESTINO" 2>/dev/null; then
echo "el directorio destino podria no estar montado correctamente"
fi

FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
NOMBRE_BACKUP="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"
echo"iniciando backup de $ORIGEN a $DESTINO/$NOMBRE_BACKUP"
tar -czf "$DESTINO/$NOMBRE_BACKUP"-C"$ORIGEN"

if [[$? -eq 0]]; then
echo "backup completado exitosamente: $DESTINO/$NOMBRE_BACKUP"
else
  echo "error al realizar el backup"
  exit 1
fi
